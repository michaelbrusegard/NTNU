#include "kernel/types.h"
#include "user/user.h"

int
main(void)
{
  ps();
  exit(0);
}
